﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerMovement : MonoBehaviour
{
    public float speed = 100;
    Rigidbody PlayerRigidbody;

    public int Score = 0;
    public int Goal = 4;
    public Text txt_Coins;

    public void OnTriggerEnter(Collider other)
    {
        if(other.tag == "Coin")
        {
            Destroy(other.gameObject);
            Score++;
            txt_Coins.text = "Coins Collected: " + Score;
        }

        if(other.tag == "Hazard")
        {
            SceneManager.LoadScene("GameLose");
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        PlayerRigidbody = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        if(Score >= Goal)
        {
            SceneManager.LoadScene("GameWin");
        }
    }

    private void FixedUpdate()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");

        Vector3 movement = new Vector3(moveHorizontal, 0, moveVertical);
        PlayerRigidbody.AddForce(movement * speed * Time.deltaTime);
    }
}
